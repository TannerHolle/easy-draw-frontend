const { Project } = require('./db/models/project.model')

module.exports = {
  Project
}
